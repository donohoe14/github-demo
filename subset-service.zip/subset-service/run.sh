#!/bin/bash
###################################################################
# Created by    : PaulDonohoe                                     #
# Date          : 16 July 2014                                    #
#                                                                 #
# Script name   : run.sh                                    	  #
# Description   : This script is used to drive gen_subset_sql.sh  #
#                 and gen_subset_txt.sh for the generation of the #
#                 sql file and the text file for the snomedCT 6   #
#                 monthly release                                 #
#                                                                 # 
# Test files drop in here: \\gold1lv\technical\releases\Subsets   #
# Results in here: \\gold1lv\Subset_Service                       #
# Info on shares at: df -k                                        #	
# cat /etc/vfstab                                                 #
###################################################################

# Set env variables as running from Jenkins so not picking up profile
export ORACLE_JDBC=/u01/app/oracle/product/11.2.0/home/jdbc/lib/ojdbc6.jar
export ORACLE_BASE=/u01/app/oracle
export TNS_ADMIN=/u01/app/oracle/product/11.2.0/home/network/admin
export ORACLE_HOME=/u01/app/oracle/product/11.2.0/home
export LD_LIBRARY_PATH=/lib:/lib:/usr/lib:/usr/openwin/lib:/usr/dt/lib:/usr/ucblib:/usr/local/lib:/lib
export PATH=$PATH:$ORACLE_HOME/bin
export EDITOR=/usr/bin/vi
export ORACLE_SID=HLI

# Go to run folder
cd /export/home/jenkins/subsets
SOURCEDIRECTORY=~/subsets

var=""

rm results.txt

errorFiles=( )
STATUS=0
INDEX=0

checkFilesExistInFolder (){

	cp /diskspace/releases/Subsets/*.txt queries
	
	fileCount=`ls queries | wc -l`  

	if [ $fileCount -lt 1 ]
	then
		echo "ERROR: No files to process in queries folder"
		exit 1
	else
		echo "Total files to process:$fileCount" 
	fi

}

clearDirectory () { 

	rm subsetsSplit/*.txt
	rm sqlscripts/*.sql
	rm queries/*.txt
	rm results/*.txt
	rm tempDirectory/*
	rm results/*.tmp
	rm reportsDirectory/*

}

removeDosLineEndings() {

	for f in `ls queries`

	do
	
		perl -w -p -e 's/\cM//;s/\s+$/\cJ/' queries/$f 

	done

}

runInFile () {
	
	for f in `ls queries`

	do

		./gen_subset_sql.sh $f

	done

}

getRetired () {

        for f in `ls subsetsSplit`
        
	do

                cat subsetsSplit/$f | while read line
                
		do
                        for word in $line
                        
			do
                                
				echo "INSERT INTO SUBSET_SERVICE_QR (FILENAME,CONCEPTID) VALUES ('$f',$word);" >> tempDirectory/allIntoLines
                        
			done
                
		done

        done
}



mergeAllInsert () {

	cat tempDirectory/allIntoLines >> tempDirectory/mergedInserts

}

mergeHeaderBodyFooter () {

	insertHeader
	insertBody 
	updateTable
	insertFooter

}

insertHeader () {
        
	echo "TRUNCATE TABLE subset_service_QR;" > reportsDirectory/insertQuery.sql

}

insertBody () {

	cat tempDirectory/mergedInserts  >> reportsDirectory/insertQuery.sql
}

updateTable () {

        echo "UPDATE SUBSET_SERVICE_QR A SET A.CONCEPTSTATUS = (SELECT B.CONCEPTSTATUS FROM SCT_CONCEPTS B WHERE A.CONCEPTID = B.CONCEPTID);
        COMMIT;
        UPDATE SUBSET_SERVICE_QR A SET A.FSN = (SELECT B.FULLYSPECIFIEDNAME FROM SCT_CONCEPTS B WHERE A.CONCEPTID = B.CONCEPTID);
        COMMIT;
        UPDATE SUBSET_SERVICE_QR SET REPLACEMENT = V31LIVE.SCTHISTORICALMAPS(CONCEPTID) WHERE CONCEPTSTATUS NOT IN (0,11);
        COMMIT;
        UPDATE SUBSET_SERVICE_QR SET REPLACEMENT = 'No Replacement - remove from subset query' WHERE REPLACEMENT = CONCEPTID; 
        COMMIT;" >> reportsDirectory/insertQuery.sql

}

insertFooter () {
	
	echo "/
	spool off
	Exit;" >> reportsDirectory/insertQuery.sql

}


textToSql () {
	
	ls sqlscripts | sed -ne 's/\([^.*txt][a-z]*\)\(.txt\)/\1/p' >> tempDirectory/outFile

	for f in `cat tempDirectory/outFile`
	
	do
        	
		cat sqlscripts/$f.txt  > sqlscripts/$f.sql
	
	done


}

runInsertSQL () {

        	sqlplus snomedctlive/snomedctlive@hli @reportsDirectory/insertQuery.sql

}

renameUnixfile (){

	prefixname="Output_"
	
	ls results | sed -ne 's/\([^.*txt][a-z]*\)\(.tmp\)/\1/p' >> tempDirectory/outUnixFile
	
	for f in `cat tempDirectory/outUnixFile`
	
	do
        	
		unix2dos -437 results/$f.tmp results/$prefixname$f.txt
	
	done

	cd ~/subsets/results
	rm ~/subsets/results/*.tmp
	
	for file in `ls *.txt`
	
	do
		
		uuencode $file $file | mailx -s "$file" "p.donohoe@nhs.net"
		#####uuencode $file $file | mailx -s "$file" "dd4c@nhs.net"
	
	done

	cp ~/subsets/results/*.txt /gold1lv_subset_service

}

checkInputOutputFilesEqual () {

	queriesFolderSize=`ls queries | wc -l`
	echo "Size of queries directory: $queriesFolderSize "
	resultsFolderSize=`ls results | wc -l`
	echo "Size of results directory: $resultsFolderSize "

	let "queriesFolderSize = queriesFolderSize + 2"
	
	if [ $queriesFolderSize -ne  $resultsFolderSize  ]
	then

		echo "ERROR: input directory size not same as output directory or no files in directories"
		exit 1
	else
	
		echo " "
	
	fi
		
}

report1 () {
	
	echo "SPOOL results/quality_checks.tmp
	SELECT 'Invalid CONCEPTIDs!!' FROM DUAL;
	SELECT FILENAME||CHR(9)||CONCEPTID
	FROM subset_service_qr WHERE CONCEPTSTATUS IS NULL;
	SPOOL OFF
	Exit;" > reportsDirectory/report1.sql

}

runReport1 () {

        	sqlplus snomedctlive/snomedctlive@hli @reportsDirectory/report1.sql

}

	
report2 () {
	
	echo "
	set trims on
	set pages 0
	set linesize 1500
	set long 999999999
	set head off
	set trimspool on
	set verify off
	set define off
        COLUMN AA FORMAT A4
	column aa format A300	
	SPOOL results/subset_query_noncurrent_report.tmp
	select 'FILENAME and LOCATION'||CHR(9)||'CONCEPTID'||CHR(9)||'CONCEPTSTATUS'||CHR(9)||'FSN'||CHR(9)||'REPLACEMENT' from dual;
	SELECT FILENAME||CHR(9)||CONCEPTID||CHR(9)||CONCEPTSTATUS||CHR(9)||FSN||CHR(9)||REPLACEMENT AA
	FROM SUBSET_SERVICE_QR
	WHERE CONCEPTSTATUS NOT IN (0,11)
	ORDER BY 1;
	SPOOL OFF
	Exit;" > reportsDirectory/report2.sql

}

runReport2 () {

        	sqlplus snomedctlive/snomedctlive@hli @reportsDirectory/report2.sql

}

report3 () {
	
	echo "
	set feedback off
	set trims on
	set pages 0
	set linesize 1500
	set long 999999999
	set head off
	set trimspool on
	set verify off
	set define off
        COLUMN AA FORMAT A4
	column aa format A300	
	SPOOL results/subset_query_replacement_names_report.tmp
	select 'CONCEPTID'||CHR(9)||'REPLACEMENT' from dual;
	SELECT CONCEPTID||CHR(9)||REPLACEMENT AA
	FROM SUBSET_SERVICE_QR
	WHERE CONCEPTSTATUS NOT IN (0,11)
	ORDER BY 1;
	SPOOL OFF
	Exit;" > reportsDirectory/report3.sql

}

runReport3 () {
        	sqlplus snomedctlive/snomedctlive@hli @reportsDirectory/report3.sql

}

sortline () {
        
	sed -ne 's/\([0-9]*\)\(.*\)/\2/p'  tempDirectory/tempfile1 > tempDirectory/tempfile3
        sed -e 's/|/ /g' tempDirectory/tempfile3 | sed -e 's/^ //g' > tempDirectory/tempfile4
        sortline3
}

sortline3 () {

        cat tempDirectory/tempfile4 | while read line

        do
                for word in $line
                
		do
                        
			echo "INSERT INTO SUBSET_SERVICE_REP_CONCEPT (CONCEPTID, CONCEPTREPLACEMENTID) VALUES ($var , $word);" >> tempDirectory/tempfile5
                
		done
        done
}

run_main () {

        var=`cat results/subset_query_replacement_names_report.txt |wc -l`

        while read p; do
                
		echo "$p" > tempDirectory/tempfile1
                var=`sed -ne 's/\([0-9]*\)\(.*\)/\1/p'  tempDirectory/tempfile1`
                sortline
        
	done < results/subset_query_replacement_names_report.tmp
        
	sed -e '1,2d' tempDirectory/tempfile5 > tempDirectory/tempfile6
}

insert_replacements () {

        echo "TRUNCATE TABLE SUBSET_SERVICE_REP_CONCEPT;" > tempDirectory/insertreplacements.sql
        cat tempDirectory/tempfile6 >> tempDirectory/insertreplacements.sql
        echo "COMMIT;
        EXIT;" >> tempDirectory/insertreplacements.sql
}

run_replacements () {

        sqlplus snomedctlive/snomedctlive@hli @tempDirectory/insertreplacements.sql

}

insert_replacements2 () {

        echo "TRUNCATE TABLE SUBSET_SERVICE_REP2_CONCEPT;
	INSERT INTO SUBSET_SERVICE_REP2_CONCEPT
	SELECT o.CONCEPTID, o.CONCEPTSTATUS, o.FULLYSPECIFIEDNAME, r.CONCEPTREPLACEMENTID
	FROM SUBSET_SERVICE_REP_CONCEPT r, SCT_CONCEPTS o
	WHERE r.CONCEPTID = o.CONCEPTID
	ORDER BY 1;
        COMMIT;
        EXIT;" > tempDirectory/insertreplacements2.sql
}


run_replacements2 () {

        sqlplus snomedctlive/snomedctlive@hli @tempDirectory/insertreplacements2.sql

}

insert_replacements3() {

        echo "TRUNCATE TABLE SUBSET_SERVICE_REP3_CONCEPT;
	INSERT INTO SUBSET_SERVICE_REP3_CONCEPT
	SELECT r.CONCEPTID, r.CONCEPTSTATUS, r.FULLYSPECIFIEDNAME, r.CONCEPTREPLACEMENTID, o.CONCEPTSTATUS, o.FULLYSPECIFIEDNAME
	FROM SUBSET_SERVICE_REP2_CONCEPT r, SCT_CONCEPTS o
	WHERE r.CONCEPTREPLACEMENTID = o.CONCEPTID
	ORDER BY 1;
        COMMIT;
        EXIT;" > tempDirectory/insertreplacements3.sql
}


run_replacements3() {

        sqlplus snomedctlive/snomedctlive@hli @tempDirectory/insertreplacements3.sql

}


report4 () {
	
	rm  report4.sql

	echo "
	set trims on
	set pages 0
	set linesize 1500
	set long 999999999
	set head off
	set trimspool on
	set verify off
	set define off
        COLUMN AA FORMAT A4
	column aa format A300	
	SPOOL results/replacement_report.tmp
	select 'CONCEPTID'||CHR(9)||'CONCEPT STATUS'||CHR(9)||'FULLY SPECIFIED NAME'||CHR(9)||'CONCEPT REPLACEMENT'||CHR(9)||'CONCEPT STATUS NEW'||CHR(9)||'REPLACEMENT FULLY SPECIFIED NAME' from dual;
	SELECT CONCEPTID||CHR(9)||CONCEPTSTATUS||CHR(9)||FULLYSPECIFIEDNAME||CHR(9)||CONCEPTREPLACEMENTID||CHR(9)||CONCEPTSTATUSNEW||CHR(9)||FULLYSPECIFIEDNAMENEW AA
	FROM SUBSET_SERVICE_REP3_CONCEPT
	ORDER BY 1;
	SPOOL OFF
	Exit;" > reportsDirectory/report4.sql

}

runReport4 () {

        	sqlplus snomedctlive/snomedctlive@hli @reportsDirectory/report4.sql

}

printReports() {

	runInsertSQL 
	report1  
	runReport1 
	report2 
	runReport2  
	report3 
	runReport3 
	run_main 
	insert_replacements 
	run_replacements 
	insert_replacements2  
	run_replacements2 
	insert_replacements3 
	run_replacements3 
	report4  
	runReport4 

}

clearDirectory
checkFilesExistInFolder
runInFile
getRetired 
textToSql
mergeAllInsert 
mergeHeaderBodyFooter 
printReports
renameUnixfile 
#####checkInputOutputFilesEqual
