#!/bin/bash                                                      
###################################################################
# Created by    : PaulDonohoe                                     #
# Date          : 16 July 2014                                    #
#                                                                 #
# Script name   : gen_subset_sql.sh                               #
# Description   : This script is used to generate the sql script  #
#                 for the snomedCT 6 monthly release              #
###################################################################

SOURCEDIRECTORY=~/subsets

fileCleanUp () {
rm query
rm nameOfFile
rm minus1
rm minus2
rm minus
rm linesplit
rm line2
rm line3

rm  footer
rm  header
rm  firstLineRemoved
rm  allExcludes2
rm  splitExcludes
rm  splitIntoLines
rm  allExcludes
rm  excludesIntoLines
rm  parentAndChildExcludes
rm  excludesChild
rm  childExcludes
rm  cherryPickedExcludes
rm  allIncludes
rm  includesIntoLines
rm  parentAndChildIncludes
rm  childIncludes
rm  cherryPickedIncludes
echo "old files deleted"
}

echo "$1" > nameOfFile
cat queries/$1 > readsubsets
arrayfile=`sed -ne 's/\([^.*txt][a-z]*\)\(.txt\)/\1/p' nameOfFile`
sqlFile="$arrayfile.txt"
tmpFile="$arrayfile.tmp"

clearDirectory () { 

	rm tempFilesDirectory/*

}

removeMinus () {

	sed -e 's/://g' readsubsets > minus1
	sed -e 's/@//g' minus1 > minus2
	sed -e 's/-//g' minus2 > minus


	sed -ne '1p' readsubsets > linesplit

	cat  linesplit | tr '[\t]' '[ ]' > line2


	cat line2 | while read line


	do
                for word in $line
                do
                        echo $word >> line3
                done
	done

	var=`grep -ni SCTRULE line3 | sed -n 's/^\([0-9]*\)[:].*/\1/p'`
	echo "varable: $var"

	cat  minus | cut  -f$var > minus2

}

#split all excludes
getAllExcludes()
{
	
	sed -e 's/\[/ [/g' minus2 |sed 's/\]/] /g' |sed 's/\[</ [</g' > splitExcludes  
	cat splitExcludes | while read line

	do
    		for word in $line
    		do
        		echo $word >> splitIntoLines
    		done
	done

	grep  '\[[<0-9|=]*]' splitIntoLines > allExcludes        
}


#remove brackets and sort into lines
removeBrackets(){

	sed -e 's/\[//g' allExcludes |sed 's/\]//g' |sed 's/|/ /g'  > allExcludes2  
	cat allExcludes2 | while read line

	do
    		for word in $line
    		do
       			echo $word >> excludesIntoLines
    		done
	done

} 

#get parent excludes
getParentAndChildExcludes ()
{
	
	grep '<<'  excludesIntoLines | sed -e 's/<<//' > parentAndChildExcludes

}

#get child excludes
getChildExcludes () 
{

	sed -e '/<</d'  excludesIntoLines > excludesChild 
	grep '<'  excludesChild | sed -e 's/<//'  > childExcludes

}

#get cherry picked excludes
getCherryPickedExcludes () 
{

	grep '='  excludesIntoLines | sed -e 's/=//' > cherryPickedExcludes

}

#sort all includes
sort_Parent_Child_CherryPicked_Includes ()
{
	grep -v '\[' splitIntoLines | sed 's/=/cp/g' | sed -e 's/<</pc/g' |sed -e 's/cp/ cp/g' | sed -e 's/|/ /g'  > allIncludes
	
	cat allIncludes | while read line

	do
    		for word in $line
    		do
        		echo $word >> includesIntoLines   
    		done
	done

}

#get parents and children includes
getParentAndChildIncudes()
{
	
	grep  'pc' includesIntoLines  | sed -e 's/pc//g' > parentAndChildIncludes  

}

#get just children includes
getChildrenIncudes()
{

	grep  '<' includesIntoLines  | sed -e 's/<//g' > childIncludes  

}

#get just cherry picked includes
getCherryPickedIncudes()
{

	grep  'cp' includesIntoLines  | sed -e 's/cp//g' > cherryPickedIncludes  

}

printResults (){

	pci=`wc -l parentAndChildIncludes`
	ci=`wc -l childIncludes`
	cpi=`wc -l cherryPickedIncludes`
	pce=`wc -l parentAndChildExcludes`
	ce=`wc -l childExcludes`
	cpe=`wc -l cherryPickedExcludes`
	
	echo "   
	=====================================================
	File processed:$sqlFile
	There are:$pci
	There are:$ci
	There are:$cpi
	There are:$pce
	There are:$ce
	There are:$cpe
	=====================================================" >> results.txt

}

insertDB () {

	nameOfFile="$2"

	echo "TRUNCATE TABLE $1;" > reportsDirectory/dolist.sql

	cat $nameOfFile | while read line

	do
    		for word in $line
    		do
				echo "INSERT INTO $1 (MEMBERID) VALUES ($word );" >> reportsDirectory/dolist.sql
    		done
	done

	echo "commit;
	Exit;" >> reportsDirectory/dolist.sql

} 	
	
addToDBTable () {

 	sqlplus snomedctlive/snomedctlive@hli @reportsDirectory/dolist.sql

}

parentAndChildrenIncludeScript () {
	
	DBname="SCT_SUBSET_PCI"
	insertDB $DBname parentAndChildIncludes
	splitname="parentAndChildrenInclude.txt"
	cat parentAndChildIncludes >> subsetsSplit/$arrayfile$splitname	
	echo "UNION
	select to_char(conceptid)||chr(9)||fullyspecifiedname
	from sct_concepts
	where conceptstatus in (0,11) and conceptid in(
	select conceptid1
	FROM sct_relationships
	WHERE relationshiptype = 116680003
	START WITH conceptid1 IN (Select MEMBERID From $DBname" >> query
	echo ") AND relationshiptype = 116680003 
	CONNECT BY PRIOR conceptid1 = conceptid2 AND relationshiptype = 116680003)" >> query

}

childrenIncludeScript () { 

	DBname="SCT_SUBSET_CI"
	insertDB $DBname childIncludes
	splitname="childrenInclude.txt"
	cat childIncludes >> subsetsSplit/$arrayfile$splitname	
	echo "UNION
	select to_char(conceptid)||chr(9)||fullyspecifiedname
	from sct_concepts
	where conceptstatus in (0,11) and conceptid in(
	select conceptid1
	FROM sct_relationships
	WHERE relationshiptype = 116680003
	AND LEVEL > 1
	START WITH conceptid1 IN (Select MEMBERID From $DBname" >> query
	echo ") AND relationshiptype = 116680003
	CONNECT BY PRIOR conceptid1 = conceptid2 AND relationshiptype = 116680003)" >> query
}

cherryPickedIncludeScript () {
	
	DBname="SCT_SUBSET_CPI"
	insertDB $DBname cherryPickedIncludes
	splitname="cherryPickedInclude.txt"
	cat cherryPickedIncludes >> subsetsSplit/$arrayfile$splitname	
	echo "UNION
	select to_char(conceptid)||chr(9)||fullyspecifiedname
	from sct_concepts
	where conceptstatus in (0,11) and conceptid in(Select MEMBERID From $DBname" >> query  
	echo ")" >> query
}

parentAndChildrenExcludeScript () {

	DBname="SCT_SUBSET_PCE"
	insertDB $DBname parentAndChildExcludes
	splitname="parentAndChildrenExclude.txt"
	cat parentAndChildExcludes >> subsetsSplit/$arrayfile$splitname	
	echo "MINUS
	select to_char(conceptid)||chr(9)||fullyspecifiedname
	from sct_concepts
	where conceptstatus in (0,11) and conceptid in(
	select conceptid1
	FROM sct_relationships
	WHERE relationshiptype = 116680003
	START WITH conceptid1 IN (Select MEMBERID From $DBname" >> query	
	echo ") AND relationshiptype = 116680003
	CONNECT BY PRIOR conceptid1 = conceptid2 AND relationshiptype = 116680003)" >> query

}

childrenExcludeScript () { 

	DBname="SCT_SUBSET_CE"
	insertDB $DBname childExcludes
	splitname="childrenExclude.txt"
	cat childExcludes >> subsetsSplit/$arrayfile$splitname	
	echo "MINUS
	select to_char(conceptid)||chr(9)||fullyspecifiedname
	from sct_concepts
	where conceptstatus in (0,11) and conceptid in(
	select conceptid1
	FROM sct_relationships
	WHERE relationshiptype = 116680003
	AND LEVEL > 1
	START WITH conceptid1 IN (Select MEMBERID From $DBname" >> query
	echo ") AND relationshiptype = 116680003
	CONNECT BY PRIOR conceptid1 = conceptid2 AND relationshiptype = 116680003)" >> query
}

cherryPickedExcludeScript () {

	DBname="SCT_SUBSET_CPE"
	insertDB $DBname cherryPickedExcludes
	splitname="cherryPickedExclude.txt"
	cat cherryPickedExcludes >> subsetsSplit/$arrayfile$splitname	
	echo "MINUS
	select to_char(conceptid)||chr(9)||fullyspecifiedname
	from sct_concepts
	where conceptstatus in (0,11) and 
	conceptid 
	in(Select MEMBERID From $DBname" >> query
	echo ")" >> query
}

header () { 

	echo "set ver off head off feed off pages 0 lines 1000 trims on echo off
	spool results/$tmpFile" > header

}

footer () { 
	
	######select to_char(conceptid)||chr(9)||fsn
	echo "MINUS
	select to_char(conceptid)
        from subset_service_excludes
	/ 
        spool off
	exit" > footer

}

addSQL () {

	if [ -s parentAndChildIncludes ]
	then
		echo "parent and child to include "
		parentAndChildrenIncludeScript
		addToDBTable
	else
		echo "No Parent and child includes to add"
	fi

	if [ -s childIncludes ]
	then
		echo "child to include"
		childrenIncludeScript
		addToDBTable
	else
		echo "No child includes to add"
	fi

	if [ -s cherryPickedIncludes ]
	then
		echo "cherry picked to include"
		cherryPickedIncludeScript 
		addToDBTable
	else
		echo "No cherry picked includes to add"
	fi

	if [ -s parentAndChildExcludes ]
	then
		echo "parent and child to exclude"
		parentAndChildrenExcludeScript 
		addToDBTable
	else
		echo "No Parent and child excludes to add"
	fi

	if [ -s childExcludes ]
	then
		echo "child to exclude"
		childrenExcludeScript  
		addToDBTable
	else
		echo "No child excludes to add"
	fi

	if [ -s cherryPickedExcludes ]
	then
		echo "Cherry Picked to excludes "
		cherryPickedExcludeScript 
		addToDBTable
	else
		echo "No cherry picked excludes to add"
	fi

}

removeFirstLine () {

	sed -e '1d' query  > firstLineRemoved  

}

merge_Header_Body_Footer () {

	cat header > /export/home/jenkins/subsets/sqlscripts/$sqlFile
	cat firstLineRemoved >> /export/home/jenkins/subsets/sqlscripts/$sqlFile
	cat footer >> /export/home/jenkins/subsets/sqlscripts/$sqlFile
	runSQLFile /export/home/jenkins/subsets/sqlscripts/$sqlFile

}

runSQLFile () {

	sqlplus snomedctlive/snomedctlive@hli @$1

}

removeMinus
getAllExcludes
removeBrackets
getParentAndChildExcludes
getChildExcludes
getCherryPickedExcludes 
sort_Parent_Child_CherryPicked_Includes 
getParentAndChildIncudes
getChildrenIncudes
getCherryPickedIncudes
addSQL 
removeFirstLine 
header
footer
merge_Header_Body_Footer
printResults 
fileCleanUp 
